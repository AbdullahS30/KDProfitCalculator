export const calculateFertilizerCommission = (acres: number, quantityPerAcre: number, commissionPerBag: number) => {
  const totalBags = acres * quantityPerAcre
  return totalBags * commissionPerBag
}

export const calculateDirectInputsCommission = (
  acres: number,
  salesValuePerAcre: number,
  commissionPercentage: number,
) => {
  return acres * salesValuePerAcre * (commissionPercentage / 100)
}

export const calculateProductBasedCommission = (
  quantity: number,
  salesValuePerUnit: number,
  commissionPercentage: number,
) => {
  return quantity * salesValuePerUnit * (commissionPercentage / 100)
}

export const calculateCropSalesCommission = (
  acres: number,
  yieldPerAcre: number,
  pricePerMaund: number,
  commissionPercentage: number,
) => {
  return acres * yieldPerAcre * pricePerMaund * (commissionPercentage / 100)
}

export const calculateMachineSalesCommission = (acres: number, costPerAcre: number, commissionPercentage: number) => {
  return acres * costPerAcre * (commissionPercentage / 100)
}

export const calculateTotalCommission = (commissions: number[]) => {
  return commissions.reduce((total, commission) => total + commission, 0)
}

export const calculateProfit = (totalRevenue: number, totalCosts: number, totalCommission: number) => {
  return totalRevenue - totalCosts + totalCommission
}


"use client"

import { useState } from "react"
import Image from "next/image"
import { Input } from "./ui/input"
import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Label } from "./ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { calculateFertilizerCommission } from "../utils/calculations"

interface FertilizerProduct {
  id: string
  name: string
  commission: number
}

const fertilizerProducts: FertilizerProduct[] = [
  { id: "urea", name: "Urea", commission: 77 },
  { id: "dap", name: "DAP", commission: 100 },
  { id: "sop", name: "SOP", commission: 90 },
  { id: "mop", name: "MOP", commission: 85 },
]

interface FertilizerInput {
  productId: string
  quantity: number
}

const ProfitCalculator = () => {
  const [landArea, setLandArea] = useState<number>(100)
  const [fertilizerInputs, setFertilizerInputs] = useState<FertilizerInput[]>([{ productId: "urea", quantity: 1 }])

  const addFertilizerInput = () => {
    setFertilizerInputs([...fertilizerInputs, { productId: "urea", quantity: 1 }])
  }

  const updateFertilizerInput = (index: number, field: keyof FertilizerInput, value: string | number) => {
    const updatedInputs = [...fertilizerInputs]
    updatedInputs[index] = { ...updatedInputs[index], [field]: value }
    setFertilizerInputs(updatedInputs)
  }

  const removeFertilizerInput = (index: number) => {
    const updatedInputs = fertilizerInputs.filter((_, i) => i !== index)
    setFertilizerInputs(updatedInputs)
  }

  const calculateTotalFertilizerCommission = () => {
    return fertilizerInputs.reduce((total, input) => {
      const product = fertilizerProducts.find((p) => p.id === input.productId)
      if (product) {
        return total + calculateFertilizerCommission(landArea, input.quantity, product.commission)
      }
      return total
    }, 0)
  }

  return (
    <div className="space-y-6 relative">
      <div className="flex justify-center mb-8">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Dukaan%20Final%20Logo-01-dPZG6IeZ5bPBJXdZZMDfwvS8nfc8kr.png"
          alt="Dukaan Logo"
          width={200}
          height={60}
          className="h-12 w-auto"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Land Information</CardTitle>
        </CardHeader>
        <CardContent>
          <Label htmlFor="landArea">Available Land Area (acres)</Label>
          <Input
            id="landArea"
            type="number"
            value={landArea}
            onChange={(e) => setLandArea(Number(e.target.value))}
            className="mt-1"
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Fertilizer Calculator</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {fertilizerInputs.map((input, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Select
                  value={input.productId}
                  onValueChange={(value) => updateFertilizerInput(index, "productId", value)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select fertilizer" />
                  </SelectTrigger>
                  <SelectContent>
                    {fertilizerProducts.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  value={input.quantity}
                  onChange={(e) => updateFertilizerInput(index, "quantity", Number(e.target.value))}
                  placeholder="Quantity per acre"
                  className="w-[150px]"
                />
                <Button variant="destructive" onClick={() => removeFertilizerInput(index)}>
                  Remove
                </Button>
              </div>
            ))}
            <Button onClick={addFertilizerInput}>Add Fertilizer</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-sm text-muted-foreground">Total Fertilizer Commission</p>
            <p className="text-2xl font-bold">₹{calculateTotalFertilizerCommission().toFixed(2)}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default ProfitCalculator

